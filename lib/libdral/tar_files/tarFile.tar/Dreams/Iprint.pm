
use 5.005;

package Dreams::Iprint;
require Exporter;

@ISA = qw/Exporter/;
@EXPORT = qw/IncIndent DecIndent ReIndentString iprint sprint sprint1 sprintv PushIndent PopIndent/;


my $sp = 0;
my @stack;
my $level = 0;
my $ws = "";

sub PushIndent
{
 $stack[$sp++] = $level;
 $stack[$sp++] = $ws;
 $level = 0;
 $ws = "";
}

sub PopIndent
{
 $ws    = $stack[--$sp];
 $level = $stack[--$sp];
}

sub IncIndent
{
 $level++;
 $ws .= "  ";
}

sub DecIndent
{
 $level--;
 $ws = substr($ws, 0, -2)
}

sub ReIndentString
{
 my($indent) = $_[0];
 my($str)    = $_[1];

 ##
 ## Add indent to begginning of string
 ##
 $str = $indent . $str;

 ##
 ## Now add it to every NewLine inside string (except to the last newline)
 ##
 $str =~ s/\n/\n$indent/g;
 $str =~ s/\n$indent$/\n/;

 return $str;
}

sub iprint
{
 foreach $str ( @_ ) {
  print ReIndentString($ws,$str);
 }
}

sub sprint
{
 my($res) = "";
 foreach $str ( @_ ) {
  $res .= ReIndentString($ws,$str);
 }
 return $res;
}

sub sprint1
{
 my($res) = "";
 IncIndent();
 foreach $str ( @_ ) {
  $res .= ReIndentString($ws,$str);
 }
 DecIndent();
 return $res;
}

sub sprintv
{
 my($n) = shift;
 my($i);
 my($res) = "";
 for ( $i = 0; $i < $n; $i++ )  { IncIndent(); }
 foreach $str ( @_ ) {
  $res .= ReIndentString($ws,$str);
 }
 for ( $i = 0; $i < $n; $i++ )  { DecIndent(); }
 return $res;
}
1;
