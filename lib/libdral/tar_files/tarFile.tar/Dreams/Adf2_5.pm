
use 5.005;

package Dreams::Adf2_5;
require Exporter;
use Dreams::Iprint;
use Dreams::DralGraph;

@ISA = qw/Exporter/;
@EXPORT = qw/Begin 
             BlankRows 
             End
             Comment 
             Edge
             ItemColorRule 
             ItemShapeRule 
             ItemFontRule 
             Node
             NodeRule 
             NodeShading 
             Rectangle 
             SetColor
             SetFont
             ShadeTable 
             Tab 
             Table 
             TagDescriptor 
            /;




sub BlankRows
{
 my($num, $color) = @_;

 iprint "<blank rows=\"$num\" color=\"$color\"/>\n";
}

##
## Wrapper to generate 2Dreams Rows for an Edge.
## Two fundamental ways to invoke: with two arguments
## or with four:
##
##  Edge( name, rule )
##  Edge( name, instance, rule )
##  Edge( name, from, to, rule )
##
## The first form will break down if the Edge's name
## is not unique in the graph
##
sub EdgeStr
{
 my($id, $name, $from, $to, $bw, $lat, $rule );
 my($inst,$str);
 
 if  ( $#_ == 1 ) {
  $name = $_[0];
  $rule = $_[1];
  ( $id, $name, $from, $to, $bw, $lat ) = FindEdge($name);
 }
 elsif  ( $#_ == 2 ) {
  $name = $_[0];
  $inst = $_[1];
  $rule = $_[2];
  ( $id, $name, $from, $to, $bw, $lat ) = FindEdge($name,$inst);
 }
 elsif  ( $#_ == 3 ) {
  $name = $_[0];
  $from = $_[1];
  $to   = $_[2];
  $rule = $_[3];
  ( $id, $name, $from, $to, $bw, $lat ) = FindEdge($name,$from,$to);
 }
 else {
  die "Edge: Wrong number of arguemtns\n";
 }

 $str  = "<edge name=\"$name\" from=\"$from\" to=\"$to\">\n"; 
 IncIndent();
 $str .= sprint $rule;
 DecIndent();
 $str .= "</edge>\n";

 return $str;
}

sub Edge
{
 iprint EdgeStr( @_ );
}

sub Node
{
 my($name,$rule) = @_;

 iprint "<node name=\"$name\">\n";
 IncIndent();
 iprint $rule;
 DecIndent();
 iprint "</node>\n";
}

sub Begin
{
 my($section) = @_; 

 if    ( $section =~ /^adf$/i ) {
  iprint "<?xml version=\"1.0\" encoding=\"ISO8859-1\"?>\n";
  iprint "<!DOCTYPE dreams2-adf PUBLIC \"-//ASIM//DTD DREAMS2/ADF 1.0//EN\"\n";
  iprint "\"http://aforge.shr.intel.com/home/asim/xml/dtd/dreams2-adf-2.0.dtd\">\n";
  iprint "<dreams-adf version=\"2.5\">\n";
  IncIndent();
 }
 elsif ( $section =~ /^ItemWindow$/i ) {
  iprint "<itemwindow>\n";
  IncIndent();
 }
 elsif ( $section =~ /^Group$/i ) {
  iprint "<group name=\"$_[1]\">\n";
  IncIndent();
 }
 elsif ( $section =~ /^2Dreams$/i ) {
  iprint "<dreams2>\n";
  IncIndent();
 }
 elsif ( $section =~ /^3Dreams$/i ) {
  iprint "<dreams3>\n";
  IncIndent();
 }
 else {
  die "Begin(\"$section\"): Unkown section type\n";
 }
}

sub End
{
 my($section) = @_; 

 if    ( $section =~ /^adf$/i ) {
  DecIndent();
  iprint "</dreams-adf>\n";
 }
 elsif ( $section =~ /^ItemWindow$/i ) {
  DecIndent();
  iprint "</itemwindow>\n";
 }
 elsif ( $section =~ /^group$/i ) {
  DecIndent();
  iprint "</group>\n";
 }
 elsif ( $section =~ /^2Dreams$/i ) {
  DecIndent();
  iprint "</dreams2>\n";
 }
 elsif ( $section =~ /^3Dreams$/i ) {
  DecIndent();
  iprint "</dreams3>\n";
 }
 else {
  die "End(\"$section\"): Unkown section type\n";
 }
}
sub Comment
{
 my($comment) = $_[0];

 iprint "<!-- $comment -->\n";
}



sub TagDescriptor
{
 my($tagname) = $_[0];
 my($type)    = $_[1];
 my($base)    = $_[2];
 my(@ValidTypes) = ( "integer", "string", "setofvalues" );
 my(@ValidBases) = ( "10", "2", "16" );
 my($str);

 die "TagDescriptor: $tagname has invalid type: $type\n" if( !grep(/$type/, @ValidTypes));
 die "TagDescriptor: $tagname has invalid base: $base\n" if( $base && !grep(/$base/, @ValidBases));

 $str = "<tagdescriptor tagname=\"$tagname\" type=\"$type\"";
 $str .= " base=\"$base\"" if ( $base );
 $str .= "/>\n";
 iprint $str;
}


sub ShadeTable
{
 my($name) = $_[0]; shift;
 my(@pairs)  = @_;
 my($i);

 die "ShadeTable: Array argument must have en EVEN number of entries\n" if ( (($#pairs + 1) % 2) != 0 );

 iprint "<shadetable name=\"$name\">\n";
 IncIndent();
 for ($i = 0; $i <= $#pairs; $i += 2 ) {
  iprint "<shade color=\"$pairs[$i]\" occupancy=\"$pairs[$i+1]\"/>\n";
 }
 DecIndent();
 iprint "</shadetable>\n";
}

sub NodeShading
{
 my($name,$tag, $table, $min, $max) = @_;
 my($mintag,$maxtag);

 $mintag = defined($min) ? " mintag=\"$min\"" : "";
 $maxtag = defined($max) ? " maxtag=\"$max\"" : "";
 iprint "<node name=\"$name\">\n";
 IncIndent();
 iprint "<shading nodetag=\"$tag\" shadetable=\"$table\" $mintag $maxtag/>\n";
 DecIndent();
 iprint "</node>\n";
}


sub SetFont
{
 my(%param) = @_;

 my($color)     = $param{'color'}     ? "color=\"$param{'color'}\""  : "";
 my($italic)    = $param{'italic'}    ? $param{'italic'}    : "false";
 my($underline) = $param{'underline'} ? $param{'underline'} : "false";
 my($bold)      = $param{'bold'}      ? $param{'bold'}      : "false";


 return "<itemfont $color italic=\"$italic\" underline=\"$underline\" bold=\"$bold\"/>\n";
}

sub SetColor
{
 my($color) = @_;
 
 return "<set color=\"$color\"/>\n";
}

sub SetShape
{
 my($shape) = @_;

 return "<set shape=\"$shape\"/>\n";
}

sub Tab
{
 my(%params) = @_;
 my($show,$tag);

 my($orderby)   = defined($params{orderby})   ? "orderby=\"$params{orderby}\""     : "";
 my($withtag)   = defined($params{withtag})   ? "withtag=\"$params{withtag}\""     : "";
 my($selecttag) = defined($params{selecttag}) ? "selecttag=\"$params{selecttag}\"" : "";
 my($value)     = defined($params{value})     ? "value=\"$params{value}\""         : "";

 die "Tab: Need both selecttag and value\n" if ( defined($params{selecttag}) ^ defined($params{value}));
 iprint "<tab name=\"$params{name}\" $withtag $selecttag $value $orderby>\n";
  IncIndent();
  $show = $params{show};
  foreach $tag ( @$show )  {
   iprint "<show itemtag=\"$tag\"/>\n";
  }
  DecIndent();
  iprint "</tab>\n";
}

sub NodeRule
{
 my($itag,$value,$action) = @_; 
 my($rule);

 $rule = "<if nodetag=\"$itag\" value=\"$value\">\n";
 IncIndent();
 $rule .= sprint $action;
 DecIndent();
 $rule .= "</if>\n";

 return $rule;
}

sub ItemRule
{
 my($itag,$value,$action)  = @_;
 my($rule) = "";

 PushIndent();
 if ( $itag ) { 
  $rule = "<if itemtag=\"$itag\" value=\"$value\">\n";
  IncIndent();
 }
 $rule .= sprint $action;
 if ( $itag ) { 
  DecIndent();
  $rule .= "</if>\n";
 }
 PopIndent();
 return $rule;
}

sub ItemFontRule
{
 my($itag)  = shift;
 my($value) = shift;
 my($font)  = shift; 
 my(@param);

 foreach $i ( @$font ) { 
  push @param, $i;
 }
 return ItemRule($itag, $value, SetFont(@param));
}

sub ItemColorRule
{
 my($itag,$value,$color) = @_; 

 return ItemRule($itag, $value, SetColor($color));
}

sub ItemShapeRule
{
 my($itag,$value,$shape) = @_; 

 return ItemRule($itag, $value, SetShape($shape));
}

###########################################################
###########################################################
####                                                 ######
####                                                 ######
####    New Commands in ADF2.5 ONLY                  ######
####                                                 ######
####                                                 ######
###########################################################
###########################################################
sub Table
{
  my($vdim) = shift @_;
  my($hdim) = shift @_;
  my(@cells) = @_;
  my($i,$j);
  my($result) = "";
  my($indent) = "    ";


  $result .= "<table>\n";
  for ($i = 0; $i < $vdim; $i++ ) {
   $result .= "$indent<tr>\n";
   for ($j = 0; $j < $hdim; $j++ ) {
    $result .= "$indent$indent<td>\n";
    $result .= ReIndentString("$indent$indent$indent", $cells[$i][$j]) .  "\n";
    $result .= "$indent$indent</td>\n";
   }
   $result .= "$indent</tr>\n";
  }
  $result .= "</table>\n";
  return $result
}

sub Rectangle
{
 my($node)   = $_[0];
 my($layout) = $_[1];
 my($inst)   = $_[2];

 return "<rectangle node=\"$node\{$inst\}\" layout=\"$layout\" />";
}


1;
