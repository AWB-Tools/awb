
use 5.005;

package Dreams::DralGraph;
require Exporter;

@ISA = qw/Exporter/;
@EXPORT = qw/ParseGraph DumpGraph FindEdge/;


sub ParseGraph
{
  my($done) = 0;

  while ( $_ = <> ) {
   if    ( /newnode (\S+) id (\d+) parent (\d+) instance (\d+)/ ) {
    $nodes[$2]{NAME} = $1;
    $nodes[$2]{PARENT} = $3;
    $nodes[$2]{INSTANCE} = $4;
   }
   elsif ( /newedge (\S+) from node (\d+) to node (\d+) id (\d+) bw (\d+) lat (\d+)/ ) {
    $edges[$4]{NAME} = $1;
    $edges[$4]{FROM} = $2;
    $edges[$4]{TO}   = $3;
    $edges[$4]{BW}   = $5;
    $edges[$4]{LAT}  = $6;
    $edgefirst{$1}   = $4 if ( ! $edgefirst{$1} || $edgefirst{$1} > $4); 
    $edgelast{$1}    = $4 if ( ! $edgelast{$1}  || $edgelast{$1}  < $4); 
   }
   elsif ( /version major (\d+) minor (\d+)/ ) {
    $major = $1;
    $minor = $2;
   }
   elsif ( /setnodelayout node (\d+) cap (.*)$/ ) {
    $nodes[$1]{LAYOUT} = $2;
   }
   else {
    die "Error Parsing Line: $_\n";
   }
  }
}

sub DumpGraph
{
 my($i);

 print "version major $major minor $minor\n";
 for ( $i = 0; $i <= $#nodes; $i++ ) {
  print "newnode $nodes[$i]{NAME} id $i parent $nodes[$i]{PARENT} instance $nodes[$i]{INSTANCE}\n";
  if ( $nodes[$i]{LAYOUT} ) {
   print "setnodelayout node $i cap $nodes[$i]{LAYOUT}\n";
  }
 }
 for ( $i = 0; $i <= $#edges; $i++ ) {
  print "newedge $edges[$i]{NAME} from node $edges[$i]{FROM} to node $edges[$i]{TO} id $i bw $edges[$i]{BW} lat $edges[$i]{LAT}\n";
 }
}

sub FindEdge
{
 my($name) = $_[0];
 my(@found) = ();
 my($debug) = 0;

 ##
 ## Scan List of edges looking for all possible Matches, starting with
 ## the hint provided by the EdgeFirst and stopping at EdgeLast
 ##
 for ( $i = $edgefirst{$name};  $i <= $edgelast{$name}; $i++ ) {
  if ( $edges[$i]{NAME} eq $name ) { push (@found, $i); }
 }
 print "FindEdge: Searched from $edgefirst{$name} to $edgelast{$name} found $#found matches\n" if ( $debug > 0); 

 ##
 ## Now filter available matches based on the extra information
 ## available based on instance number, and from/to info
 ##
 ## First Case: we are given just a name, without from/to and without
 ## instance number. It must be the case that there is a single edge with
 ## this name.
 ##
 if ( $#_ == 0 ) {
  $#found == 0 || die "Multiple ambigous matches found for $name: Provide more info to disambiguate\n";
  $i = $found[0];
  $from = $nodes[$edges[$i]{FROM}]{NAME} . "{" .  $nodes[$edges[$i]{FROM}]{INSTANCE} . "}";
  $to   = $nodes[$edges[$i]{TO}]{NAME}   . "{" .  $nodes[$edges[$i]{TO}]{INSTANCE}   . "}";
  return ( $i, $edges[$i]{NAME}, $from, $to, $edges[$i]{BW}, $edges[$i]{LAT} );
 }
 ##
 ## Second Case: We have a Name and an instance number. We scan all
 ## matches looking for those cases where both "from" and "to" have the
 ## instance number provided.
 ##
 elsif ( $#_ == 1 ) {
  $instance = $_[1];
  for ( $i = 0; $i <= $#found; $i++ ) {
   $eid       = $found[$i];
   $from      = $edges[$eid]{FROM};
   $to        = $edges[$eid]{TO};
   $from_inst = $nodes[$from]{INSTANCE};
   $to_inst   = $nodes[$to]{INSTANCE};
   if ( $from_inst == $instance && $to_inst == $instance ) {
    $from = $nodes[$from]{NAME} . "{" .  $nodes[$from]{INSTANCE} .  "}";
    $to   = $nodes[$to]{NAME}   . "{" .  $nodes[$to]{INSTANCE}   .  "}";
    return ( $eid, $edges[$eid]{NAME}, $from, $to, $edges[$eid]{BW}, $edges[$eid]{LAT} );
   }
  }
  die "Could not find match for $name instance $instance\n";
 }
 ##
 ## Third Case: we are given explicit from/to commands. We need  to find
 ## the edge that exactly goes from the source to the dest node. Also,
 ## note that from/to may have embedded and instance number of the form [\d+]
 ## or of the form <\d+>, so we need to extract those before performing the
 ## search.
 elsif ( $#_ == 2 ) {
  $from = $_[1];
  $to   = $_[2];
  $from_inst = $to_inst = -1;
  if ( $from =~ /\[/ ) {
   $from =~ s/\[(\d+)\]\s*$//;
   $from_inst = $1;
  }
  if ( $to =~ /\[/ ) {
   $to =~ s/\[(\d+)\]\s*$//;
   $to_inst = $1;
  }
  print "Searching for $from ($_[1]) inst $from_inst\n" if ( $debug > 0);
  print "Searching for $to ($_[2]) inst $to_inst\n" if ( $debug > 0);
  for ( $i = 0; $i <= $#found; $i++ ) {
   $found_eid       = $found[$i];
   $found_from      = $edges[$found_eid]{FROM};
   $found_to        = $edges[$found_eid]{TO};
   $found_from_inst = $nodes[$found_from]{INSTANCE};
   $found_to_inst   = $nodes[$found_to]{INSTANCE};
   $match = ( $from_inst == -1 || $found_from_inst == $from_inst ) && 
            ( $to_inst   == -1 || $found_to_inst   == $to_inst   ) &&
            ( $from eq $nodes[$found_from]{NAME}                 ) &&
            ( $to   eq $nodes[$found_to]{NAME}                   );

   print   "( $from_inst == -1 || $found_from_inst == $from_inst ) &&\n ".
           "( $to_inst   == -1 || $found_to_inst   == $to_inst   ) &&\n".
           "( <$from> eq <$nodes[$found_from]{NAME}>                 ) &&\n".
           "( <$to>   eq <$nodes[$found_to]{NAME}>                   )\n" if ( $debug > 0);
   
   $src = $nodes[$found_from]{NAME} . "{" .  $nodes[$found_from]{INSTANCE} . "}";
   $dst   = $nodes[$found_to]{NAME} . "{" .  $nodes[$found_to]{INSTANCE}   . "}";
   print "$found_eid, $edges[$found_eid]{NAME}, $src, $dst, $edges[$found_eid]{BW}, $edges[$found_eid]{LAT} \n" if ( $debug > 0);
   if ( $match ) {
    print "MATCH!!!\n" if ( $debug > 0);
    return ( $found_eid, $edges[$found_eid]{NAME}, $src, $dst, $edges[$found_eid]{BW}, $edges[$found_eid]{LAT} );
   }
  }
  die "FindEdge: Could not find edge $_[0] from $_[1] to $_[2]\n";
 }
 else {
  die "Wrong Number of Parameters for FindEdge\n";
 }
}

1;
